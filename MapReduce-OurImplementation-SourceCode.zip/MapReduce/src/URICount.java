import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class URICount {
	public static boolean lock = false;

	public static void main(String[] args) throws IOException, InterruptedException {
		//FileInputStream inputstream = new FileInputStream(args[0]);
		FileInputStream inputstream = new FileInputStream("input.txt");
		BufferedReader reader = new BufferedReader(new InputStreamReader(inputstream));
		int lines = 0;
		while (reader.readLine() != null)
			lines++;

		inputstream.getChannel().position(0);

		//int numMappers = Integer.parseInt(args[1]);
		//int numReducers = Integer.parseInt(args[2]);
		int numMappers = 6;
		int numReducers = 3;
		int linesPerMapper = (int) Math.ceil(lines * 1.0 / numMappers);

		//MapperThread mapthread[] = new MapperThread[numMappers];
		List<MapperThread> mapThreadList = new ArrayList<MapperThread>();
		//ExecutorService mapExecutor = Executors.newFixedThreadPool(numMappers);

		String keys;
		int totalline = 0;
		
		PrintWriter pw = new PrintWriter("MapperOutputFiles.txt");
		for (int thread = 0; thread < numMappers; thread++) {
			keys = "";
			int readerline = 0;
			while (readerline < linesPerMapper && totalline < lines) {
				keys += reader.readLine() + " ";
				readerline++;
				totalline++;
			}
			
			mapThreadList.add(thread, new MapperThread(keys.trim(), thread, pw));
			mapThreadList.get(thread).setPriority(Thread.MAX_PRIORITY);
			mapThreadList.get(thread).start();
			//mapthread[thread] = new MapperThread(keys.trim(), thread, pw);
			//mapthread[thread].start();
			
		}
		for(int i=0;i<numMappers;i++){
			while(mapThreadList.get(i).isAlive()){
				mapThreadList.get(i).join();
			}
		}
		pw.close();
		//mapThreadList.clear();
		reader.close();
		System.out.println("Mapper execution finished.");

		FileInputStream inputstream2 = new FileInputStream("MapperOutputFiles.txt");
		BufferedReader reader2 = new BufferedReader(new InputStreamReader(inputstream2));
		int outputfiles = 0;
		while (reader2.readLine() != null)
			outputfiles++;

		inputstream2.getChannel().position(0);
		String filename = "";
		String rkeys;
		int rtotalline;
		PrintWriter rpw = new PrintWriter("ReducerOutputFiles.txt");
		//ReducerThread reducethread[] = new ReducerThread[numReducers];
		List<ReducerThread> reduceThreadList = new ArrayList<ReducerThread>();
		//ExecutorService reduceExecutor = Executors.newFixedThreadPool(numReducers);
		
		StringBuilder sb[] = new StringBuilder[numReducers];
		for (int reducer = 0; reducer < numReducers; reducer++) {
			sb[reducer] = new StringBuilder();
		}
		for (int file = 0; file < outputfiles; file++) {
			rtotalline = 0;
			filename = reader2.readLine();
			FileInputStream inputstream3 = new FileInputStream(filename);
			BufferedReader reader3 = new BufferedReader(new InputStreamReader(inputstream3));

			int filelines = 0;
			while (reader3.readLine() != null)
				filelines++;

			int linesPerReducer = (int) Math.ceil(filelines * 1.0 / numReducers);

			inputstream3.getChannel().position(0);
			for (int reducer = 0; reducer < numReducers; reducer++) {
				rkeys = "";
				int r_readerline = 0;
				while (r_readerline < linesPerReducer && rtotalline < filelines) {
					rkeys += reader3.readLine() + " ";
					r_readerline++;
					rtotalline++;
				}
				sb[reducer].append(rkeys);
			}
			reader3.close();
		}
		for (int reducer = 0; reducer < numReducers; reducer++) {
			reduceThreadList.add(reducer, new ReducerThread(sb[reducer].toString(), reducer, rpw));
			reduceThreadList.get(reducer).setPriority(Thread.MAX_PRIORITY);
			reduceThreadList.get(reducer).start();
			//reduceExecutor.execute(new ReducerThread(sb[reducer].toString(), reducer, rpw));
			//reducethread[reducer] = new ReducerThread(sb[reducer].toString(), reducer, rpw);
			//reducethread[reducer].start();
		}
		for(int i=0;i<numReducers;i++){
			while(reduceThreadList.get(i).isAlive()){
				reduceThreadList.get(i).join();
			}
		}
		rpw.close();
		//reduceThreadList.clear();
		reader2.close();
		System.out.println("Reducer execution finished");
		
		FileInputStream inputstream3 = new FileInputStream("ReducerOutputFiles.txt");
		BufferedReader reader3 = new BufferedReader(new InputStreamReader(inputstream3));
		PrintWriter finalReducer = new PrintWriter("ReducerFinalOutputFile.txt");
		
		int reducerOutputFiles = 0;
		while (reader3.readLine() != null)
			reducerOutputFiles++;

		inputstream3.getChannel().position(0);
		
		String reducerOutputs = "";
		for (int file = 0; file < reducerOutputFiles; file++) {
			rtotalline = 0;
			filename = reader3.readLine();
			FileInputStream inputstream4 = new FileInputStream(filename);
			BufferedReader reader4 = new BufferedReader(new InputStreamReader(inputstream4));
			
			String line = reader4.readLine();
			while(line != null){
				reducerOutputs += line+" ";
				line = reader4.readLine();
			}
			
			reader4.close();
		}
		
		
		reduceThreadList.add(numReducers, new ReducerThread(reducerOutputs));
		reduceThreadList.get(numReducers).setPriority(Thread.MAX_PRIORITY);
		reduceThreadList.get(numReducers).start();
		
		reader3.close();
		finalReducer.close();
		System.out.println("Final Reducer Execution Finished.");
	}

}

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class MapperThread extends Thread{
	String keys;
	int thread;
	PrintWriter pw;
	
	public MapperThread(String keys, int thread, PrintWriter pw) {
		this.keys = keys;
		this.thread = thread;
		this.pw = pw;
	}
	public void run(){
		Map map = new Map();
		try {
			synchronized(this){
				String file = map.map(keys, thread);
				System.out.println(file);
				pw.write(file);
				pw.println();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		} 
	}
}

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class Map {

	public String map(String keys, int count) throws FileNotFoundException {
		long timeBeforeMapper;
		synchronized(this) {
			timeBeforeMapper = System.nanoTime();
		}
		PrintWriter file = new PrintWriter("MapOutput" + count + ".txt");
		StringTokenizer itr = new StringTokenizer(keys + " ");
		while (itr.hasMoreTokens()) {
			String key = itr.nextToken().toString();
			file.write(key + ":" + 1);
			file.println();
		}
		file.close();
		long totalTime;
		synchronized (this) {
			totalTime = (System.nanoTime() - timeBeforeMapper) / 1000000;
		}
		
		System.out.println("Time taken by Mapper " + count + " is " + totalTime + " milliseconds");
		return "MapOutput" + count + ".txt";
	}

}

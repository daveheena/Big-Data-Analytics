import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.StringTokenizer;

public class Reduce {

	public String reduce(String keys, int count) throws FileNotFoundException {
		long timeBeforeReducer;
		synchronized(this) {
			timeBeforeReducer = System.nanoTime();
		}
		PrintWriter file = new PrintWriter("ReduceOutput" + count + ".txt");
		StringTokenizer itr = new StringTokenizer(keys + " ");
		HashMap<String, Integer> reducer = new HashMap<String, Integer>();
		
		while (itr.hasMoreTokens()) {
			String token[] = itr.nextToken().toString().split(":");
			if (reducer.containsKey(token[0])) {
				int value = reducer.get(token[0]);
				reducer.remove(token[0]);
				reducer.put(token[0], value + 1);
			} else {
				reducer.put(token[0], 1);
			}

		}
		for (String keyset : reducer.keySet()) {
			file.write(keyset + ":" + reducer.get(keyset));
			file.println();
		}
		file.close();
		long totalTime;
		synchronized (this) {
			totalTime = (System.nanoTime() - timeBeforeReducer) / 1000000;
		}
		System.out.println("Time taken by Reducer " + count + " is " + totalTime + " milliseconds");
		return "ReduceOutput" + count + ".txt";
	}

	public String finalReducer(String keys) throws FileNotFoundException {
		long timeBeforeFReducer;
		synchronized(this) {
			timeBeforeFReducer = System.nanoTime();
		}
		PrintWriter file = new PrintWriter("ReducerFinalOutput.txt");
		StringTokenizer itr = new StringTokenizer(keys + " ");
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		while (itr.hasMoreTokens()) {
			String token[] = itr.nextToken().toString().split(":");
			if (map.containsKey(token[0])) {
				int value = map.get(token[0]);
				map.remove(token[0]);
				map.put(token[0], value + Integer.parseInt(token[1]));
			} else {
				map.put(token[0], Integer.parseInt(token[1]));
			}

		}
		for (String keyset : map.keySet()) {
			file.write(keyset + ":" + map.get(keyset));
			file.println();
		}
		file.close();
		long totalTime;
		synchronized (this) {
			totalTime = (System.nanoTime() - timeBeforeFReducer) / 1000000;
		}
		System.out.println("Time taken by Final Reducer is " + totalTime + " milliseconds");
		return "ReduceFinalOutput.txt";
	}
}
